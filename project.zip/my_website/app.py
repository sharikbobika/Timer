from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def home():
    # Сервер просто берет и отправляет красивую страничку в браузер
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)